"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Globe, Smartphone, Settings, ShoppingCart, Zap, Cloud, Users, Wrench } from "lucide-react"
import { useLanguage } from "@/components/LanguageProvider"

export function Solutions() {
  const { t } = useLanguage()

  const solutions = [
    {
      icon: Globe,
      title: t("solutions.web.title"),
      description: t("solutions.web.description"),
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
    },
    {
      icon: Smartphone,
      title: t("solutions.mobile.title"),
      description: t("solutions.mobile.description"),
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
    },
    {
      icon: Settings,
      title: t("solutions.custom.title"),
      description: t("solutions.custom.description"),
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
    },
    {
      icon: ShoppingCart,
      title: t("solutions.ecommerce.title"),
      description: t("solutions.ecommerce.description"),
      color: "text-green-500",
      bgColor: "bg-green-500/10",
    },
    {
      icon: Zap,
      title: t("solutions.api.title"),
      description: t("solutions.api.description"),
      color: "text-yellow-500",
      bgColor: "bg-yellow-500/10",
    },
    {
      icon: Cloud,
      title: t("solutions.cloud.title"),
      description: t("solutions.cloud.description"),
      color: "text-cyan-500",
      bgColor: "bg-cyan-500/10",
    },
    {
      icon: Users,
      title: t("solutions.consulting.title"),
      description: t("solutions.consulting.description"),
      color: "text-pink-500",
      bgColor: "bg-pink-500/10",
    },
    {
      icon: Wrench,
      title: t("solutions.maintenance.title"),
      description: t("solutions.maintenance.description"),
      color: "text-red-500",
      bgColor: "bg-red-500/10",
    },
  ]

  return (
    <section className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">{t("solutions.title")}</h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">{t("solutions.subtitle")}</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {solutions.map((solution, index) => (
            <Card
              key={index}
              className="bg-gray-900 border-gray-800 hover:border-[#92d81e]/50 transition-all duration-300 group"
            >
              <CardHeader className="text-center">
                <div
                  className={`w-16 h-16 mx-auto mb-4 rounded-full ${solution.bgColor} flex items-center justify-center group-hover:scale-110 transition-transform`}
                >
                  <solution.icon className={`w-8 h-8 ${solution.color}`} />
                </div>
                <CardTitle className="text-white text-lg">{solution.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400 text-center text-sm">{solution.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
