"use client"

import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle, Users, Award, Clock } from "lucide-react"
import { useLanguage } from "@/components/LanguageProvider"

export function Chosen() {
  const { t } = useLanguage()

  const reasons = [
    {
      icon: Users,
      title: t("chosen.team.title"),
      description: t("chosen.team.description"),
    },
    {
      icon: Award,
      title: t("chosen.quality.title"),
      description: t("chosen.quality.description"),
    },
    {
      icon: Clock,
      title: t("chosen.delivery.title"),
      description: t("chosen.delivery.description"),
    },
    {
      icon: CheckCircle,
      title: t("chosen.support.title"),
      description: t("chosen.support.description"),
    },
  ]

  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">{t("chosen.title")}</h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">{t("chosen.subtitle")}</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {reasons.map((reason, index) => (
            <Card
              key={index}
              className="bg-black border-gray-800 hover:border-[#92d81e]/50 transition-all duration-300 group text-center"
            >
              <CardContent className="p-8">
                <div className="w-16 h-16 mx-auto mb-6 bg-[#92d81e]/10 rounded-full flex items-center justify-center group-hover:bg-[#92d81e]/20 transition-colors">
                  <reason.icon className="w-8 h-8 text-[#92d81e]" />
                </div>
                <h3 className="text-xl font-bold text-white mb-4">{reason.title}</h3>
                <p className="text-gray-400">{reason.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
