"use client"

import { useLanguage } from "./LanguageProvider"
import { Globe } from "lucide-react"

export function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage()

  return (
    <div className="relative">
      <div className="flex items-center bg-gradient-to-r from-[#121225] to-[#1a1a2e] rounded-full p-1 border border-gray-700/50 backdrop-blur-sm">
        <Globe className="w-4 h-4 text-[#92d81e] mr-2 ml-2" />
        <button
          onClick={() => setLanguage("pt")}
          className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all duration-300 ${
            language === "pt"
              ? "bg-[#92d81e] text-black shadow-lg transform scale-105"
              : "text-gray-300 hover:text-white hover:bg-gray-800/50"
          }`}
        >
          PT
        </button>
        <div className="w-px h-4 bg-gray-600 mx-1" />
        <button
          onClick={() => setLanguage("en")}
          className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all duration-300 ${
            language === "en"
              ? "bg-[#92d81e] text-black shadow-lg transform scale-105"
              : "text-gray-300 hover:text-white hover:bg-gray-800/50"
          }`}
        >
          EN
        </button>
      </div>
    </div>
  )
}
